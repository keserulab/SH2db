from django.apps import AppConfig


class ProteinConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'protein'
